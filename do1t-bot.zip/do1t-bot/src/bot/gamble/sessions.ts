export interface WoFSession {
  type: "wof";
  id: string;
  guildId: string;
  initiatorId: string;
  opponentId: string;
  initiatorBet: number | null;
  opponentBet: number | null;
  channelId: string | null;
  p1BetMsgId: string | null;
  p2BetMsgId: string | null;
  spinMessageId: string | null;
  spunBy: Set<string>;
  phase: "pending_accept" | "betting_p1" | "betting_p2" | "spinning" | "done";
}

export interface BJSession {
  type: "bj";
  id: string;
  guildId: string;
  playerId: string;
  gems: number;
  bet: number | null;
  channelId: string;
  betMsgId: string | null;
  gameMessageId: string | null;
  playerHand: Array<{ face: string; value: number }>;
  dealerHand: Array<{ face: string; value: number }>;
  phase: "betting" | "playing" | "done";
  timeoutId: ReturnType<typeof setTimeout> | null;
}

export interface JackpotSession {
  type: "jackpot";
  id: string;
  guildId: string;
  initiatorId: string;
  opponentId: string;
  initiatorBet: number | null;
  opponentBet: number | null;
  channelId: string | null;
  betMsgId: string | null;
  gameMessageId: string | null;
  p1Numbers: number[] | null;
  p2Numbers: number[] | null;
  phase:
    | "pending_accept"
    | "betting_p1"
    | "betting_p2"
    | "spinning_p1"
    | "spinning_p2"
    | "done";
}

export type GambleSession = WoFSession | BJSession | JackpotSession;

const pendingGems = new Map<string, number>();
const sessions = new Map<string, GambleSession>();

export function setPendingGems(userId: string, gems: number): void {
  pendingGems.set(userId, gems);
}
export function getPendingGems(userId: string): number | undefined {
  return pendingGems.get(userId);
}
export function clearPendingGems(userId: string): void {
  pendingGems.delete(userId);
}

export function generateSessionId(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function createSession(session: GambleSession): void {
  sessions.set(session.id, session);
}

export function getSession(id: string): GambleSession | undefined {
  return sessions.get(id);
}

export function getWoFSession(id: string): WoFSession | undefined {
  const s = sessions.get(id);
  return s?.type === "wof" ? s : undefined;
}

export function getBJSession(id: string): BJSession | undefined {
  const s = sessions.get(id);
  return s?.type === "bj" ? s : undefined;
}

export function getJackpotSession(id: string): JackpotSession | undefined {
  const s = sessions.get(id);
  return s?.type === "jackpot" ? s : undefined;
}

export function deleteSession(id: string): void {
  const s = sessions.get(id);
  if (s?.type === "bj" && s.timeoutId) clearTimeout(s.timeoutId);
  sessions.delete(id);
}

export function hasActiveSession(userId: string): boolean {
  if (pendingGems.has(userId)) return true;
  for (const s of sessions.values()) {
    if (s.phase === "done") continue;
    if (s.type === "bj" && s.playerId === userId) return true;
    if (
      (s.type === "wof" || s.type === "jackpot") &&
      (s.initiatorId === userId || s.opponentId === userId)
    )
      return true;
  }
  return false;
}
