import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  TextChannel,
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type Guild,
  type GuildMember,
} from "discord.js";
import { logger } from "../../lib/logger";
import {
  setPendingGems,
  getPendingGems,
  clearPendingGems,
  generateSessionId,
  createSession,
  getWoFSession,
  deleteSession,
} from "./sessions";

const GAMBLE_COMMAND_CHANNEL = "1507499696590164129";
const OPPONENT_ROLE_ID = "1494828281701204081";
const GAMBLE_CATEGORY_ID = "1507504933006479360";

async function getNextWoFNumber(guild: Guild): Promise<number> {
  await guild.channels.fetch().catch(() => {});
  let max = 0;
  for (const ch of guild.channels.cache.values()) {
    if (ch.parentId !== GAMBLE_CATEGORY_ID) continue;
    const m = ch.name.match(/^gamble-(\d+)$/i);
    if (m) {
      const n = parseInt(m[1]!);
      if (n > max) max = n;
    }
  }
  return max + 1;
}

export function showWoFGemsModal(interaction: ButtonInteraction): Promise<void> {
  const userId = interaction.user.id;
  const modal = new ModalBuilder()
    .setCustomId(`gb_mgem_${userId}`)
    .setTitle("💎 Wheel of Fortune — Setup");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("gem_count")
        .setLabel("How many gems do you have?")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("e.g. 500")
        .setRequired(true)
        .setMaxLength(10),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleWoFButton(
  interaction: ButtonInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("gb_acc_")) {
    const sid = id.slice("gb_acc_".length);
    const session = getWoFSession(sid);
    if (!session) {
      await interaction.reply({ content: "This challenge has expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (interaction.user.id !== session.opponentId) {
      await interaction.reply({ content: "This challenge is not for you!", flags: MessageFlags.Ephemeral });
      return true;
    }

    const guild = interaction.guild!;
    const num = await getNextWoFNumber(guild);

    const gambleChannel = await guild.channels.create({
      name: `gamble-${num}`,
      type: ChannelType.GuildText,
      parent: GAMBLE_CATEGORY_ID,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: session.initiatorId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: session.opponentId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: interaction.client.user!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
      ],
    });

    session.channelId = gambleChannel.id;
    session.phase = "betting_p1";

    await interaction.message.delete().catch(() => {});
    await interaction.deferUpdate().catch(() => {});

    const embed = new EmbedBuilder()
      .setTitle("🎰 Wheel of Fortune")
      .setDescription(
        `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
        `<@${session.initiatorId}> **(Player 1)**, how many gems do you want to bet?`,
      )
      .setColor(0x5865f2)
      .setFooter({ text: "Do1T Discord" });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`gb_bet_${sid}_p1`).setLabel("💎 Place My Bet").setStyle(ButtonStyle.Success),
    );

    const msg = await gambleChannel.send({ content: `<@${session.initiatorId}> <@${session.opponentId}>`, embeds: [embed], components: [row] });
    session.p1BetMsgId = msg.id;
    return true;
  }

  if (id.startsWith("gb_dec_")) {
    const sid = id.slice("gb_dec_".length);
    const session = getWoFSession(sid);
    if (!session) {
      await interaction.reply({ content: "This challenge has expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (interaction.user.id !== session.opponentId) {
      await interaction.reply({ content: "This challenge is not for you!", flags: MessageFlags.Ephemeral });
      return true;
    }
    deleteSession(sid);
    await interaction.message.delete().catch(() => {});
    const warn = await (interaction.channel as TextChannel).send(`<@${session.initiatorId}> Your Wheel of Fortune challenge was declined. 😔`);
    await interaction.deferUpdate().catch(() => {});
    setTimeout(() => warn.delete().catch(() => {}), 5000);
    return true;
  }

  if (id.startsWith("gb_bet_")) {
    const parts = id.split("_");
    const sid = parts[2]!;
    const who = parts[3]!;
    const session = getWoFSession(sid);
    if (!session) {
      await interaction.reply({ content: "Session expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    const expectedId = who === "p1" ? session.initiatorId : session.opponentId;
    if (interaction.user.id !== expectedId) {
      await interaction.reply({ content: "It's not your turn to bet!", flags: MessageFlags.Ephemeral });
      return true;
    }
    const modal = new ModalBuilder().setCustomId(`gb_mbet_${sid}_${who}`).setTitle("💎 Your Bet");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("bet_amount").setLabel("Gems to Bet").setStyle(TextInputStyle.Short).setPlaceholder("e.g. 100").setRequired(true).setMaxLength(10),
      ),
    );
    await interaction.showModal(modal);
    return true;
  }

  if (id.startsWith("gb_spin_")) {
    const sid = id.slice("gb_spin_".length);
    const session = getWoFSession(sid);
    if (!session || session.phase !== "spinning") {
      await interaction.reply({ content: "Cannot spin right now.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (interaction.user.id !== session.initiatorId && interaction.user.id !== session.opponentId) {
      await interaction.reply({ content: "You are not part of this gamble!", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (session.spunBy.has(interaction.user.id)) {
      await interaction.reply({ content: "You already spun! Waiting for the other player...", flags: MessageFlags.Ephemeral });
      return true;
    }

    session.spunBy.add(interaction.user.id);

    if (session.spunBy.size === 1) {
      await interaction.reply({ content: `✅ <@${interaction.user.id}> has spun! Waiting for the other player...`, flags: MessageFlags.Ephemeral });
      const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;
      if (ch && session.spinMessageId) {
        const spinMsg = await ch.messages.fetch(session.spinMessageId).catch(() => null);
        if (spinMsg?.embeds[0]) {
          await spinMsg.edit({
            embeds: [EmbedBuilder.from(spinMsg.embeds[0]).setDescription(
              `🎡 **The wheel is spinning...**\n\n` +
              `💎 <@${session.initiatorId}> **(P1)** bets **${session.initiatorBet}** gems\n` +
              `💎 <@${session.opponentId}> **(P2)** bets **${session.opponentBet}** gems\n\n` +
              `🔵🔴🔵🔴🔵🔴🔵🔴🔵🔴\n\n` +
              `✅ One player has spun! Waiting for the other...`,
            )],
          }).catch(() => {});
        }
      }
      return true;
    }

    await interaction.deferUpdate().catch(() => {});

    const winner = Math.random() < 0.5 ? "p1" : "p2";
    const winnerId = winner === "p1" ? session.initiatorId : session.opponentId;
    const loserId = winner === "p1" ? session.opponentId : session.initiatorId;
    const loserBet = winner === "p1" ? session.opponentBet! : session.initiatorBet!;

    const resultEmbed = new EmbedBuilder()
      .setTitle("🎡 The Wheel Has Spoken!")
      .setDescription(
        `🔵🔴🔵🔴🔵🔴🔵🔴🔵🔴\n` +
        `P1 | P2 | P1 | P2 | P1 | P2 | P1 | P2 | P1 | P2\n\n` +
        `🏆 **${winner === "p1" ? "Player 1" : "Player 2"} (<@${winnerId}>) wins!**\n\n` +
        `<@${loserId}>, you must pay <@${winnerId}> **${loserBet} gems**! 💸`,
      )
      .setColor(winner === "p1" ? 0x3498db : 0xe74c3c)
      .setFooter({ text: "Do1T Discord" })
      .setTimestamp();

    const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;
    if (ch && session.spinMessageId) {
      const spinMsg = await ch.messages.fetch(session.spinMessageId).catch(() => null);
      if (spinMsg) await spinMsg.edit({ embeds: [resultEmbed], components: [] }).catch(() => {});
    }

    session.phase = "done";
    deleteSession(sid);
    return true;
  }

  return false;
}

export async function handleWoFModal(
  interaction: ModalSubmitInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("gb_mgem_")) {
    const userId = id.slice("gb_mgem_".length);
    if (interaction.user.id !== userId) return true;

    const gems = parseInt(interaction.fields.getTextInputValue("gem_count").trim());
    if (isNaN(gems) || gems <= 0) {
      await interaction.reply({ content: "❌ Enter a valid gem count.", flags: MessageFlags.Ephemeral });
      return true;
    }

    setPendingGems(userId, gems);

    const guild = interaction.guild!;
    await guild.members.fetch().catch(() => {});
    const role = guild.roles.cache.get(OPPONENT_ROLE_ID);
    const eligible = role?.members.filter((m: GuildMember) => m.id !== userId) ?? new Map<string, GuildMember>();

    if (eligible.size === 0) {
      clearPendingGems(userId);
      await interaction.reply({ content: "❌ No eligible opponents found.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const options = [...eligible.values()].slice(0, 25).map((m: GuildMember) =>
      new StringSelectMenuOptionBuilder().setLabel(m.displayName.slice(0, 100)).setValue(m.id).setDescription(`@${m.user.username}`.slice(0, 100)),
    );

    await interaction.reply({
      content: `💎 You have **${gems} gems**. Who do you want to go up against?`,
      components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder().setCustomId(`gb_opp_${userId}`).setPlaceholder("Choose your opponent...").addOptions(options),
      )],
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (id.startsWith("gb_mbet_")) {
    const parts = id.split("_");
    const sid = parts[2]!;
    const who = parts[3]!;
    const session = getWoFSession(sid);

    if (!session) {
      await interaction.reply({ content: "Session expired.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const bet = parseInt(interaction.fields.getTextInputValue("bet_amount").trim());
    if (isNaN(bet) || bet <= 0) {
      await interaction.reply({ content: "❌ Enter a valid bet amount.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;

    if (who === "p1") {
      session.initiatorBet = bet;
      session.phase = "betting_p2";

      if (ch && session.p1BetMsgId) {
        const p1Msg = await ch.messages.fetch(session.p1BetMsgId).catch(() => null);
        if (p1Msg) {
          const updated = new EmbedBuilder()
            .setTitle("🎰 Wheel of Fortune")
            .setDescription(
              `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
              `✅ <@${session.initiatorId}> has placed their bet!\n\n` +
              `<@${session.opponentId}> **(Player 2)**, how many gems do you want to bet?`,
            )
            .setColor(0x5865f2)
            .setFooter({ text: "Do1T Discord" });

          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`gb_bet_${sid}_p2`).setLabel("💎 Place My Bet").setStyle(ButtonStyle.Success),
          );
          await p1Msg.edit({ embeds: [updated], components: [row] }).catch(() => {});
          session.p2BetMsgId = p1Msg.id;
        }
      }
      await interaction.reply({ content: `✅ Bet of **${bet} gems** placed! Waiting for the other player...`, flags: MessageFlags.Ephemeral });
    } else {
      session.opponentBet = bet;
      session.phase = "spinning";

      if (ch && session.p2BetMsgId) {
        const p2Msg = await ch.messages.fetch(session.p2BetMsgId).catch(() => null);
        if (p2Msg) {
          const spinEmbed = new EmbedBuilder()
            .setTitle("🎡 Wheel of Fortune — Spin Time!")
            .setDescription(
              `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
              `💎 <@${session.initiatorId}> bets **${session.initiatorBet}** gems\n` +
              `💎 <@${session.opponentId}> bets **${session.opponentBet}** gems\n\n` +
              `🔵🔴🔵🔴🔵🔴🔵🔴🔵🔴\n` +
              `**5 sections for each player — 50/50 chance!**\n\n` +
              `**Both players must click Spin! to reveal the result!**`,
            )
            .setColor(0xffd700)
            .setFooter({ text: "Do1T Discord" });

          const spinRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`gb_spin_${sid}`).setLabel("🎡 Spin!").setStyle(ButtonStyle.Danger),
          );

          const spinMsg = await p2Msg.edit({ embeds: [spinEmbed], components: [spinRow] }).catch(() => null);
          if (spinMsg) session.spinMessageId = spinMsg.id;
        }
      }
      await interaction.reply({ content: `✅ Bet of **${bet} gems** placed! Click **Spin!** when ready!`, flags: MessageFlags.Ephemeral });
    }
    return true;
  }

  return false;
}

export async function handleWoFSelect(
  interaction: StringSelectMenuInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("gb_opp_")) {
    const userId = id.slice("gb_opp_".length);
    if (interaction.user.id !== userId) {
      await interaction.reply({ content: "This is not your selection!", flags: MessageFlags.Ephemeral });
      return true;
    }

    const gems = getPendingGems(userId);
    if (gems === undefined) {
      await interaction.reply({ content: "Session expired. Use !start again.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const opponentId = interaction.values[0]!;
    clearPendingGems(userId);

    const sid = generateSessionId();
    createSession({
      type: "wof",
      id: sid,
      guildId: interaction.guild!.id,
      initiatorId: userId,
      opponentId,
      initiatorBet: null,
      opponentBet: null,
      channelId: null,
      p1BetMsgId: null,
      p2BetMsgId: null,
      spinMessageId: null,
      spunBy: new Set(),
      phase: "pending_accept",
    });

    await interaction.update({
      content: `✅ Challenge sent to <@${opponentId}>! Waiting...`,
      components: [],
    });

    const cmdChannel = interaction.guild!.channels.cache.get(GAMBLE_COMMAND_CHANNEL) as TextChannel;
    if (cmdChannel) {
      const embed = new EmbedBuilder()
        .setTitle("⚔️ Wheel of Fortune Challenge!")
        .setDescription(
          `<@${opponentId}>, <@${userId}> challenges you to a **Wheel of Fortune** duel!\n\n` +
          `💎 They have **${gems} gems**. Do you accept?`,
        )
        .setColor(0xff6b35)
        .setFooter({ text: "Do1T Discord" });

      await cmdChannel.send({
        content: `<@${opponentId}>`,
        embeds: [embed],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId(`gb_acc_${sid}`).setLabel("✅ Accept").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`gb_dec_${sid}`).setLabel("❌ Decline").setStyle(ButtonStyle.Danger),
        )],
      });
    }
    return true;
  }

  return false;
}
