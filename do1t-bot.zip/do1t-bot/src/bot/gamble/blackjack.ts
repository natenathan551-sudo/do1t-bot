import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  TextChannel,
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type Guild,
} from "discord.js";
import { logger } from "../../lib/logger";
import {
  generateSessionId,
  createSession,
  getBJSession,
  deleteSession,
} from "./sessions";

const GAMBLE_CATEGORY_ID = "1507504933006479360";

const SUITS = ["♠", "♥", "♦", "♣"];
const RANK_FACES = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function randomCard(): { face: string; value: number } {
  const rank = Math.ceil(Math.random() * 13);
  const suit = SUITS[Math.floor(Math.random() * 4)]!;
  const face = RANK_FACES[rank]! + suit;
  const value = rank === 1 ? 11 : Math.min(rank, 10);
  return { face, value };
}

function handValue(hand: Array<{ face: string; value: number }>): number {
  let total = hand.reduce((s, c) => s + c.value, 0);
  let aces = hand.filter((c) => c.face.startsWith("A")).length;
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  return total;
}

function displayHand(hand: Array<{ face: string; value: number }>, hideSecond = false): string {
  if (hideSecond && hand.length >= 2) {
    return `\`${hand[0]!.face}\` \`❓\``;
  }
  return hand.map((c) => `\`${c.face}\``).join(" ");
}

async function getNextBJNumber(guild: Guild): Promise<number> {
  await guild.channels.fetch().catch(() => {});
  let max = 0;
  for (const ch of guild.channels.cache.values()) {
    if (ch.parentId !== GAMBLE_CATEGORY_ID) continue;
    const m = ch.name.match(/^gamblebj-(\d+)$/i);
    if (m) {
      const n = parseInt(m[1]!);
      if (n > max) max = n;
    }
  }
  return max + 1;
}

function buildGameEmbed(
  session: ReturnType<typeof getBJSession>,
  statusLine: string,
  showDealer = false,
): EmbedBuilder {
  if (!session) return new EmbedBuilder();
  const playerVal = handValue(session.playerHand);
  const dealerVal = showDealer ? handValue(session.dealerHand) : null;

  return new EmbedBuilder()
    .setTitle("🃏 BlackJack")
    .setDescription(
      `💎 **Bet:** ${session.bet} gems\n\n` +
      `🧑 **Your hand:** ${displayHand(session.playerHand)} — **${playerVal}**\n` +
      `🤖 **Dealer's hand:** ${showDealer ? displayHand(session.dealerHand) + ` — **${dealerVal}**` : displayHand(session.dealerHand, true)}\n\n` +
      statusLine,
    )
    .setColor(0x2ecc71)
    .setFooter({ text: "Do1T Discord • You have 1 minute!" });
}

async function resolveGame(
  sid: string,
  guild: Guild,
  autoStand = false,
): Promise<void> {
  const session = getBJSession(sid);
  if (!session || session.phase !== "playing") return;
  session.phase = "done";

  if (session.timeoutId) {
    clearTimeout(session.timeoutId);
    session.timeoutId = null;
  }

  const ch = guild.channels.cache.get(session.channelId) as TextChannel | undefined;
  if (!ch) { deleteSession(sid); return; }

  const gameMsg = session.gameMessageId
    ? await ch.messages.fetch(session.gameMessageId).catch(() => null)
    : null;

  const playerVal = handValue(session.playerHand);

  let dealerVal = handValue(session.dealerHand);
  while (dealerVal < 17) {
    session.dealerHand.push(randomCard());
    dealerVal = handValue(session.dealerHand);
  }

  let resultTitle: string;
  let resultDesc: string;
  let color: number;

  const playerBust = playerVal > 21;
  const dealerBust = dealerVal > 21;

  if (autoStand) {
    resultDesc = `⏰ Time's up! You were auto-stood.\n\n`;
  } else {
    resultDesc = "";
  }

  if (playerBust) {
    resultTitle = "💥 Bust! Dealer Wins!";
    resultDesc += `You went over 21! Better luck next time... 😬\n\nPay up **${session.bet} gems** to **Local Bot** (the server owner)! 💸`;
    color = 0xe74c3c;
  } else if (dealerBust) {
    resultTitle = "🎉 Dealer Busts — You Win!";
    resultDesc += `The dealer went over 21! You're on fire! 🔥\n\nCongrats, **you win ${(session.bet ?? 0) * 2} gems** (2x your bet)! 💰`;
    color = 0x2ecc71;
  } else if (playerVal > dealerVal) {
    resultTitle = "🏆 You Win!";
    resultDesc += `**${playerVal}** beats the dealer's **${dealerVal}**! Incredible!\n\nCongrats, **you win ${(session.bet ?? 0) * 2} gems** (2x your bet)! 💰`;
    color = 0x2ecc71;
  } else if (dealerVal > playerVal) {
    resultTitle = "😔 Dealer Wins!";
    resultDesc += `Dealer's **${dealerVal}** beats your **${playerVal}**. So close!\n\nBetter luck next time. Pay up **${session.bet} gems** to **Local Bot** (the server owner)! 💸`;
    color = 0xe74c3c;
  } else {
    resultTitle = "🤝 Push — Dealer Wins Ties!";
    resultDesc += `Both at **${playerVal}**! Dealer wins ties.\n\nBetter luck next time. Pay up **${session.bet} gems** to **Local Bot** (the server owner)! 💸`;
    color = 0xf39c12;
  }

  const resultEmbed = new EmbedBuilder()
    .setTitle(resultTitle)
    .setDescription(
      `💎 **Bet:** ${session.bet} gems\n\n` +
      `🧑 **Your final hand:** ${displayHand(session.playerHand)} — **${playerVal}**\n` +
      `🤖 **Dealer's final hand:** ${displayHand(session.dealerHand)} — **${dealerVal}**\n\n` +
      resultDesc,
    )
    .setColor(color)
    .setFooter({ text: "Do1T Discord" })
    .setTimestamp();

  if (gameMsg) {
    await gameMsg.edit({ embeds: [resultEmbed], components: [] }).catch(() => {});
  } else {
    await ch.send({ embeds: [resultEmbed] }).catch(() => {});
  }

  deleteSession(sid);
}

export function showBJGemsModal(interaction: ButtonInteraction): Promise<void> {
  const userId = interaction.user.id;
  const modal = new ModalBuilder()
    .setCustomId(`bj_mgem_${userId}`)
    .setTitle("🃏 BlackJack — Setup");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("gem_count")
        .setLabel("How many gems do you have?")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("e.g. 500")
        .setRequired(true)
        .setMaxLength(10),
    ),
  );
  return interaction.showModal(modal);
}

export async function handleBJButton(
  interaction: ButtonInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("bj_bet_")) {
    const sid = id.slice("bj_bet_".length);
    const session = getBJSession(sid);
    if (!session || session.playerId !== interaction.user.id) {
      await interaction.reply({ content: "Not your game!", flags: MessageFlags.Ephemeral });
      return true;
    }
    const modal = new ModalBuilder().setCustomId(`bj_mbet_${sid}`).setTitle("💎 How much do you want to bet?");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("bet_amount").setLabel("Gems to Bet").setStyle(TextInputStyle.Short).setPlaceholder("e.g. 100").setRequired(true).setMaxLength(10),
      ),
    );
    await interaction.showModal(modal);
    return true;
  }

  if (id.startsWith("bj_hit_")) {
    const sid = id.slice("bj_hit_".length);
    const session = getBJSession(sid);
    if (!session || session.phase !== "playing") {
      await interaction.reply({ content: "Game not active.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (session.playerId !== interaction.user.id) {
      await interaction.reply({ content: "Not your game!", flags: MessageFlags.Ephemeral });
      return true;
    }

    session.playerHand.push(randomCard());
    const playerVal = handValue(session.playerHand);

    const ch = interaction.guild!.channels.cache.get(session.channelId) as TextChannel;

    if (playerVal > 21) {
      await interaction.deferUpdate().catch(() => {});
      await resolveGame(sid, interaction.guild!);
      return true;
    }

    const gameMsg = session.gameMessageId ? await ch.messages.fetch(session.gameMessageId).catch(() => null) : null;
    const embed = buildGameEmbed(session, `🃏 You drew a card! Your total is now **${playerVal}**.\nHit again or Stand?`);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`bj_hit_${sid}`).setLabel("🃏 Hit").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`bj_stand_${sid}`).setLabel("🛑 Stand").setStyle(ButtonStyle.Secondary),
    );

    if (gameMsg) {
      await gameMsg.edit({ embeds: [embed], components: [row] }).catch(() => {});
    }
    await interaction.deferUpdate().catch(() => {});
    return true;
  }

  if (id.startsWith("bj_stand_")) {
    const sid = id.slice("bj_stand_".length);
    const session = getBJSession(sid);
    if (!session || session.phase !== "playing") {
      await interaction.reply({ content: "Game not active.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (session.playerId !== interaction.user.id) {
      await interaction.reply({ content: "Not your game!", flags: MessageFlags.Ephemeral });
      return true;
    }

    await interaction.deferUpdate().catch(() => {});
    await resolveGame(sid, interaction.guild!);
    return true;
  }

  return false;
}

export async function handleBJModal(
  interaction: ModalSubmitInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("bj_mgem_")) {
    const userId = id.slice("bj_mgem_".length);
    if (interaction.user.id !== userId) return true;

    const gems = parseInt(interaction.fields.getTextInputValue("gem_count").trim());
    if (isNaN(gems) || gems <= 0) {
      await interaction.reply({ content: "❌ Enter a valid gem count.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const guild = interaction.guild!;
    const num = await getNextBJNumber(guild);

    const bjChannel = await guild.channels.create({
      name: `gamblebj-${num}`,
      type: ChannelType.GuildText,
      parent: GAMBLE_CATEGORY_ID,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: userId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: interaction.client.user!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
      ],
    });

    const sid = generateSessionId();
    createSession({
      type: "bj",
      id: sid,
      guildId: guild.id,
      playerId: userId,
      gems,
      bet: null,
      channelId: bjChannel.id,
      betMsgId: null,
      gameMessageId: null,
      playerHand: [],
      dealerHand: [],
      phase: "betting",
      timeoutId: null,
    });

    const betEmbed = new EmbedBuilder()
      .setTitle("🃏 BlackJack — Place Your Bet!")
      .setDescription(
        `Welcome to **BlackJack**, <@${userId}>! 🎰\n\n` +
        `💎 You have **${gems} gems**.\n` +
        `How many gems do you want to bet? Click below!`,
      )
      .setColor(0x2ecc71)
      .setFooter({ text: "Do1T Discord • vs The House" });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`bj_bet_${sid}`).setLabel("💎 Place Bet").setStyle(ButtonStyle.Success),
    );

    const betMsg = await bjChannel.send({ content: `<@${userId}>`, embeds: [betEmbed], components: [row] });

    const session = getBJSession(sid);
    if (session) session.betMsgId = betMsg.id;

    await interaction.reply({
      content: `🃏 Your BlackJack table is ready! Head to <#${bjChannel.id}>!`,
      flags: MessageFlags.Ephemeral,
    });
    return true;
  }

  if (id.startsWith("bj_mbet_")) {
    const sid = id.slice("bj_mbet_".length);
    const session = getBJSession(sid);

    if (!session || session.playerId !== interaction.user.id) {
      await interaction.reply({ content: "Session not found.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const bet = parseInt(interaction.fields.getTextInputValue("bet_amount").trim());
    if (isNaN(bet) || bet <= 0) {
      await interaction.reply({ content: "❌ Enter a valid bet amount.", flags: MessageFlags.Ephemeral });
      return true;
    }

    session.bet = bet;
    session.phase = "playing";

    const p1 = randomCard();
    const p2 = randomCard();
    const d1 = randomCard();
    const d2 = randomCard();
    session.playerHand = [p1, p2];
    session.dealerHand = [d1, d2];

    const playerVal = handValue(session.playerHand);

    const ch = interaction.guild!.channels.cache.get(session.channelId) as TextChannel;

    if (session.betMsgId) {
      const betMsg = await ch.messages.fetch(session.betMsgId).catch(() => null);
      if (betMsg) await betMsg.delete().catch(() => {});
    }

    const isBlackjack = playerVal === 21 && session.playerHand.length === 2;

    if (isBlackjack) {
      session.phase = "done";
      const bjEmbed = new EmbedBuilder()
        .setTitle("🎉 BLACKJACK! Instant Win!")
        .setDescription(
          `💎 **Bet:** ${bet} gems\n\n` +
          `🧑 **Your hand:** ${displayHand(session.playerHand)} — **21** 🃏\n` +
          `🤖 **Dealer's hand:** ${displayHand(session.dealerHand)} — **${handValue(session.dealerHand)}**\n\n` +
          `🎉 **BLACKJACK!** You got 21 on your first two cards!\n` +
          `Congrats, **you win ${Math.floor(bet * 2.5)} gems** (2.5x for Blackjack)! 💰`,
        )
        .setColor(0xffd700)
        .setFooter({ text: "Do1T Discord" })
        .setTimestamp();

      await interaction.reply({ embeds: [bjEmbed] });
      deleteSession(sid);
      return true;
    }

    const embed = buildGameEmbed(
      session,
      `🎰 The cards have been dealt! Your total is **${playerVal}**.\n` +
      `What do you want to do?\n\n⏰ You have **1 minute** to play!`,
    );

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`bj_hit_${sid}`).setLabel("🃏 Hit").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`bj_stand_${sid}`).setLabel("🛑 Stand").setStyle(ButtonStyle.Secondary),
    );

    const gameMsg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
    session.gameMessageId = gameMsg.id;

    session.timeoutId = setTimeout(async () => {
      logger.info({ sid }, "BJ session timed out — auto-standing");
      const guild = interaction.guild;
      if (guild) await resolveGame(sid, guild, true);
    }, 60_000);

    return true;
  }

  return false;
}
