import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextChannel,
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type Guild,
  type GuildMember,
} from "discord.js";
import { logger } from "../../lib/logger";
import {
  generateSessionId,
  createSession,
  getJackpotSession,
  deleteSession,
} from "./sessions";

const GAMBLE_COMMAND_CHANNEL = "1507499696590164129";
const OPPONENT_ROLE_ID = "1494828281701204081";
const GAMBLE_CATEGORY_ID = "1507504933006479360";

async function getNextJackpotNumber(guild: Guild): Promise<number> {
  await guild.channels.fetch().catch(() => {});
  let max = 0;
  for (const ch of guild.channels.cache.values()) {
    if (ch.parentId !== GAMBLE_CATEGORY_ID) continue;
    const m = ch.name.match(/^gamblejack-(\d+)$/i);
    if (m) {
      const n = parseInt(m[1]!);
      if (n > max) max = n;
    }
  }
  return max + 1;
}

function rollThree(): number[] {
  return [
    Math.floor(Math.random() * 10) + 1,
    Math.floor(Math.random() * 10) + 1,
    Math.floor(Math.random() * 10) + 1,
  ];
}

export async function showJackpotOpponentSelect(
  interaction: ButtonInteraction,
): Promise<void> {
  const userId = interaction.user.id;
  const guild = interaction.guild!;
  await guild.members.fetch().catch(() => {});
  const role = guild.roles.cache.get(OPPONENT_ROLE_ID);
  const eligible = role?.members.filter((m: GuildMember) => m.id !== userId) ?? new Map<string, GuildMember>();

  if (eligible.size === 0) {
    await interaction.reply({ content: "❌ No eligible opponents found.", flags: MessageFlags.Ephemeral });
    return;
  }

  const options = [...eligible.values()].slice(0, 25).map((m: GuildMember) =>
    new StringSelectMenuOptionBuilder().setLabel(m.displayName.slice(0, 100)).setValue(m.id).setDescription(`@${m.user.username}`.slice(0, 100)),
  );

  await interaction.reply({
    content: "🎰 **Jackpot** — Who do you want to go up against?",
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder().setCustomId(`jp_opp_${userId}`).setPlaceholder("Choose your opponent...").addOptions(options),
    )],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleJackpotButton(
  interaction: ButtonInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("jp_acc_")) {
    const sid = id.slice("jp_acc_".length);
    const session = getJackpotSession(sid);
    if (!session) {
      await interaction.reply({ content: "This challenge has expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (interaction.user.id !== session.opponentId) {
      await interaction.reply({ content: "This challenge is not for you!", flags: MessageFlags.Ephemeral });
      return true;
    }

    const guild = interaction.guild!;
    const num = await getNextJackpotNumber(guild);

    const jackChannel = await guild.channels.create({
      name: `gamblejack-${num}`,
      type: ChannelType.GuildText,
      parent: GAMBLE_CATEGORY_ID,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: session.initiatorId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: session.opponentId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: interaction.client.user!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
      ],
    });

    session.channelId = jackChannel.id;
    session.phase = "betting_p1";

    await interaction.message.delete().catch(() => {});
    await interaction.deferUpdate().catch(() => {});

    const embed = new EmbedBuilder()
      .setTitle("🎰 Jackpot — Place Your Bets!")
      .setDescription(
        `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
        `💎 <@${session.initiatorId}> **(Player 1)**, how many gems do you want to bet?\n\n` +
        `_Each player will roll 3 random numbers (1–10). Highest total wins!_ 🎲`,
      )
      .setColor(0x9b59b6)
      .setFooter({ text: "Do1T Discord" });

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`jp_bet_${sid}_p1`).setLabel("💎 Place My Bet").setStyle(ButtonStyle.Success),
    );

    const msg = await jackChannel.send({ content: `<@${session.initiatorId}> <@${session.opponentId}>`, embeds: [embed], components: [row] });
    session.betMsgId = msg.id;
    return true;
  }

  if (id.startsWith("jp_dec_")) {
    const sid = id.slice("jp_dec_".length);
    const session = getJackpotSession(sid);
    if (!session) {
      await interaction.reply({ content: "This challenge has expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (interaction.user.id !== session.opponentId) {
      await interaction.reply({ content: "This challenge is not for you!", flags: MessageFlags.Ephemeral });
      return true;
    }
    deleteSession(sid);
    await interaction.message.delete().catch(() => {});
    const warn = await (interaction.channel as TextChannel).send(`<@${session.initiatorId}> Your Jackpot challenge was declined. 😔`);
    await interaction.deferUpdate().catch(() => {});
    setTimeout(() => warn.delete().catch(() => {}), 5000);
    return true;
  }

  if (id.startsWith("jp_bet_")) {
    const parts = id.split("_");
    const sid = parts[2]!;
    const who = parts[3]!;
    const session = getJackpotSession(sid);
    if (!session) {
      await interaction.reply({ content: "Session expired.", flags: MessageFlags.Ephemeral });
      return true;
    }
    const expectedId = who === "p1" ? session.initiatorId : session.opponentId;
    if (interaction.user.id !== expectedId) {
      await interaction.reply({ content: "It's not your turn to bet!", flags: MessageFlags.Ephemeral });
      return true;
    }
    const modal = new ModalBuilder().setCustomId(`jp_mbet_${sid}_${who}`).setTitle("💰 Your Jackpot Bet");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("bet_amount").setLabel("Gems to Bet").setStyle(TextInputStyle.Short).setPlaceholder("e.g. 200").setRequired(true).setMaxLength(10),
      ),
    );
    await interaction.showModal(modal);
    return true;
  }

  if (id.startsWith("jp_spin_")) {
    const sid = id.slice("jp_spin_".length);
    const session = getJackpotSession(sid);
    if (!session) {
      await interaction.reply({ content: "Session expired.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const isP1 = interaction.user.id === session.initiatorId;
    const isP2 = interaction.user.id === session.opponentId;

    if (!isP1 && !isP2) {
      await interaction.reply({ content: "You are not part of this game!", flags: MessageFlags.Ephemeral });
      return true;
    }

    if (session.phase === "spinning_p1") {
      if (!isP1) {
        await interaction.reply({ content: "It's Player 1's turn to spin!", flags: MessageFlags.Ephemeral });
        return true;
      }

      const nums = rollThree();
      session.p1Numbers = nums;
      session.phase = "spinning_p2";

      const total = nums.reduce((a, b) => a + b, 0);

      const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;
      const gameMsg = session.gameMessageId ? await ch.messages.fetch(session.gameMessageId).catch(() => null) : null;

      const embed = new EmbedBuilder()
        .setTitle("🎰 Jackpot — Player 1 Rolled!")
        .setDescription(
          `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
          `🎲 **<@${session.initiatorId}> rolled:** \`${nums[0]}\` + \`${nums[1]}\` + \`${nums[2]}\` = **${total}**!\n\n` +
          `👀 Now it's your turn, <@${session.opponentId}>! Can you beat **${total}**?\n` +
          `Click **Spin!** to roll your numbers!`,
        )
        .setColor(0x9b59b6)
        .setFooter({ text: "Do1T Discord" });

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`jp_spin_${sid}`).setLabel("🎲 Spin!").setStyle(ButtonStyle.Danger),
      );

      if (gameMsg) {
        await gameMsg.edit({ embeds: [embed], components: [row] }).catch(() => {});
      }
      await interaction.deferUpdate().catch(() => {});
      return true;
    }

    if (session.phase === "spinning_p2") {
      if (!isP2) {
        await interaction.reply({ content: "It's Player 2's turn to spin!", flags: MessageFlags.Ephemeral });
        return true;
      }

      const nums = rollThree();
      session.p2Numbers = nums;
      session.phase = "done";

      await interaction.deferUpdate().catch(() => {});

      const p1Nums = session.p1Numbers!;
      const p1Total = p1Nums.reduce((a, b) => a + b, 0);
      const p2Total = nums.reduce((a, b) => a + b, 0);

      let winnerId: string;
      let loserId: string;
      let loserBet: number;
      let resultLine: string;

      if (p1Total > p2Total) {
        winnerId = session.initiatorId;
        loserId = session.opponentId;
        loserBet = session.opponentBet!;
        resultLine = `🏆 **<@${winnerId}> (P1) wins** with **${p1Total}** vs **${p2Total}**!\n\n<@${loserId}> (P2), pay up **${loserBet} gems** to <@${winnerId}>! 💸`;
      } else if (p2Total > p1Total) {
        winnerId = session.opponentId;
        loserId = session.initiatorId;
        loserBet = session.initiatorBet!;
        resultLine = `🏆 **<@${winnerId}> (P2) wins** with **${p2Total}** vs **${p1Total}**!\n\n<@${loserId}> (P1), pay up **${loserBet} gems** to <@${winnerId}>! 💸`;
      } else {
        resultLine = `🤝 **It's a tie at ${p1Total}!** Both players keep their gems. Well played! 🎯`;
        winnerId = "";
        loserId = "";
        loserBet = 0;
      }

      const resultEmbed = new EmbedBuilder()
        .setTitle("🎰 JACKPOT RESULTS!")
        .setDescription(
          `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
          `🎲 **<@${session.initiatorId}> rolled:** \`${p1Nums[0]}\` + \`${p1Nums[1]}\` + \`${p1Nums[2]}\` = **${p1Total}**\n` +
          `🎲 **<@${session.opponentId}> rolled:** \`${nums[0]}\` + \`${nums[1]}\` + \`${nums[2]}\` = **${p2Total}**\n\n` +
          resultLine,
        )
        .setColor(0xffd700)
        .setFooter({ text: "Do1T Discord" })
        .setTimestamp();

      const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;
      const gameMsg = session.gameMessageId ? await ch.messages.fetch(session.gameMessageId).catch(() => null) : null;
      if (gameMsg) {
        await gameMsg.edit({ embeds: [resultEmbed], components: [] }).catch(() => {});
      } else {
        await ch.send({ embeds: [resultEmbed] }).catch(() => {});
      }

      deleteSession(sid);
      return true;
    }

    return true;
  }

  return false;
}

export async function handleJackpotModal(
  interaction: ModalSubmitInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("jp_mbet_")) {
    const parts = id.split("_");
    const sid = parts[2]!;
    const who = parts[3]!;
    const session = getJackpotSession(sid);

    if (!session) {
      await interaction.reply({ content: "Session expired.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const bet = parseInt(interaction.fields.getTextInputValue("bet_amount").trim());
    if (isNaN(bet) || bet <= 0) {
      await interaction.reply({ content: "❌ Enter a valid bet amount.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const ch = interaction.guild!.channels.cache.get(session.channelId!) as TextChannel;

    if (who === "p1") {
      session.initiatorBet = bet;
      session.phase = "betting_p2";

      if (ch && session.betMsgId) {
        const betMsg = await ch.messages.fetch(session.betMsgId).catch(() => null);
        if (betMsg) {
          const embed = new EmbedBuilder()
            .setTitle("🎰 Jackpot — Place Your Bets!")
            .setDescription(
              `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
              `✅ <@${session.initiatorId}> has placed their bet!\n\n` +
              `💎 <@${session.opponentId}> **(Player 2)**, how many gems do you want to bet?\n\n` +
              `_Each player will roll 3 random numbers (1–10). Highest total wins!_ 🎲`,
            )
            .setColor(0x9b59b6)
            .setFooter({ text: "Do1T Discord" });

          const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`jp_bet_${sid}_p2`).setLabel("💎 Place My Bet").setStyle(ButtonStyle.Success),
          );
          await betMsg.edit({ embeds: [embed], components: [row] }).catch(() => {});
        }
      }
      await interaction.reply({ content: `✅ Bet of **${bet} gems** placed! Waiting for Player 2...`, flags: MessageFlags.Ephemeral });
    } else {
      session.opponentBet = bet;
      session.phase = "spinning_p1";

      if (ch && session.betMsgId) {
        const betMsg = await ch.messages.fetch(session.betMsgId).catch(() => null);
        if (betMsg) {
          const gameEmbed = new EmbedBuilder()
            .setTitle("🎰 JACKPOT — Let's Roll!")
            .setDescription(
              `⚔️ <@${session.initiatorId}> **(P1)** vs <@${session.opponentId}> **(P2)**\n\n` +
              `💎 <@${session.initiatorId}> bets **${session.initiatorBet}** gems\n` +
              `💎 <@${session.opponentId}> bets **${session.opponentBet}** gems\n\n` +
              `🎲 Each player rolls **3 numbers (1–10)** — highest total wins!\n\n` +
              `<@${session.initiatorId}> **(Player 1)**, you go first! Click **Spin!** 🎰`,
            )
            .setColor(0x9b59b6)
            .setFooter({ text: "Do1T Discord" });

          const spinRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`jp_spin_${sid}`).setLabel("🎲 Spin!").setStyle(ButtonStyle.Danger),
          );

          const gameMsg = await betMsg.edit({ embeds: [gameEmbed], components: [spinRow] }).catch(() => null);
          if (gameMsg) session.gameMessageId = gameMsg.id;
        }
      }
      await interaction.reply({ content: `✅ Bet of **${bet} gems** placed! Game is starting — check the channel!`, flags: MessageFlags.Ephemeral });
    }
    return true;
  }

  return false;
}

export async function handleJackpotSelect(
  interaction: StringSelectMenuInteraction,
): Promise<boolean> {
  const id = interaction.customId;

  if (id.startsWith("jp_opp_")) {
    const userId = id.slice("jp_opp_".length);
    if (interaction.user.id !== userId) {
      await interaction.reply({ content: "This is not your selection!", flags: MessageFlags.Ephemeral });
      return true;
    }

    const opponentId = interaction.values[0]!;
    const sid = generateSessionId();

    createSession({
      type: "jackpot",
      id: sid,
      guildId: interaction.guild!.id,
      initiatorId: userId,
      opponentId,
      initiatorBet: null,
      opponentBet: null,
      channelId: null,
      betMsgId: null,
      gameMessageId: null,
      p1Numbers: null,
      p2Numbers: null,
      phase: "pending_accept",
    });

    await interaction.update({
      content: `✅ Jackpot challenge sent to <@${opponentId}>! Waiting...`,
      components: [],
    });

    const cmdChannel = interaction.guild!.channels.cache.get(GAMBLE_COMMAND_CHANNEL) as TextChannel;
    if (cmdChannel) {
      const embed = new EmbedBuilder()
        .setTitle("🎰 Jackpot Challenge!")
        .setDescription(
          `<@${opponentId}>, <@${userId}> is challenging you to a **Jackpot** showdown!\n\n` +
          `🎲 Roll 3 numbers each — highest total takes the gems!\n\nDo you accept?`,
        )
        .setColor(0x9b59b6)
        .setFooter({ text: "Do1T Discord" });

      await cmdChannel.send({
        content: `<@${opponentId}>`,
        embeds: [embed],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId(`jp_acc_${sid}`).setLabel("✅ Accept").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`jp_dec_${sid}`).setLabel("❌ Decline").setStyle(ButtonStyle.Danger),
        )],
      });
    }
    return true;
  }

  return false;
}
