import {
  type Client,
  Events,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  TextChannel,
  type Message,
  type Interaction,
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
} from "discord.js";
import { logger } from "../../lib/logger";
import { hasActiveSession } from "./sessions";
import {
  showWoFGemsModal,
  handleWoFButton,
  handleWoFModal,
  handleWoFSelect,
} from "./wof";
import {
  showBJGemsModal,
  handleBJButton,
  handleBJModal,
} from "./blackjack";
import {
  showJackpotOpponentSelect,
  handleJackpotButton,
  handleJackpotModal,
  handleJackpotSelect,
} from "./jackpot";

const GAMBLE_COMMAND_CHANNEL = "1507499696590164129";

export function registerGamble(client: Client): void {
  client.on(Events.MessageCreate, async (message: Message) => {
    if (message.author.bot) return;
    if (message.channelId !== GAMBLE_COMMAND_CHANNEL) return;
    if (message.content.trim().toLowerCase() !== "!start") return;

    await message.delete().catch(() => {});

    if (hasActiveSession(message.author.id)) {
      const warn = await (message.channel as TextChannel).send(
        `<@${message.author.id}> You already have an active gamble session! Finish it first.`,
      );
      setTimeout(() => warn.delete().catch(() => {}), 5000);
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle("🎰 Do1T Gambling Den")
      .setDescription(
        `<@${message.author.id}> wants to start a gamble!\n\n` +
        `Click **Set Up Gamble** to choose your game!`,
      )
      .setColor(0xffd700);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`gb_setup_${message.author.id}`)
        .setLabel("🎲 Set Up Gamble")
        .setStyle(ButtonStyle.Primary),
    );

    await (message.channel as TextChannel).send({ embeds: [embed], components: [row] });
  });

  client.on(Events.InteractionCreate, async (interaction: Interaction) => {
    try {
      const customId =
        "customId" in interaction ? (interaction.customId as string) : "";

      if (interaction.isButton()) {
        const btn = interaction as ButtonInteraction;

        if (customId.startsWith("gb_setup_")) {
          const userId = customId.slice("gb_setup_".length);
          if (btn.user.id !== userId) {
            await btn.reply({ content: "This button is not for you!", flags: MessageFlags.Ephemeral });
            return;
          }

          const gameEmbed = new EmbedBuilder()
            .setTitle("🎮 Choose Your Game")
            .setDescription(
              "Pick which game you'd like to play:\n\n" +
              "🎡 **Wheel of Fortune** — Bet against another player, spin the wheel, winner takes all!\n\n" +
              "🃏 **BlackJack** — Play against the house! Get closer to 21 than the dealer to win 2x your bet.\n\n" +
              "🎰 **Jackpot** — Challenge a player to a number roll-off! Roll 3 numbers each, highest total wins!",
            )
            .setColor(0xffd700);

          const gameRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder().setCustomId(`gb_game_wof_${userId}`).setLabel("🎡 Wheel of Fortune").setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId(`gb_game_bj_${userId}`).setLabel("🃏 BlackJack").setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`gb_game_jp_${userId}`).setLabel("🎰 Jackpot").setStyle(ButtonStyle.Danger),
          );

          await btn.reply({ embeds: [gameEmbed], components: [gameRow], flags: MessageFlags.Ephemeral });
          return;
        }

        if (customId.startsWith("gb_game_wof_")) {
          const userId = customId.slice("gb_game_wof_".length);
          if (btn.user.id !== userId) {
            await btn.reply({ content: "This button is not for you!", flags: MessageFlags.Ephemeral });
            return;
          }
          await showWoFGemsModal(btn);
          return;
        }

        if (customId.startsWith("gb_game_bj_")) {
          const userId = customId.slice("gb_game_bj_".length);
          if (btn.user.id !== userId) {
            await btn.reply({ content: "This button is not for you!", flags: MessageFlags.Ephemeral });
            return;
          }
          await showBJGemsModal(btn);
          return;
        }

        if (customId.startsWith("gb_game_jp_")) {
          const userId = customId.slice("gb_game_jp_".length);
          if (btn.user.id !== userId) {
            await btn.reply({ content: "This button is not for you!", flags: MessageFlags.Ephemeral });
            return;
          }
          await showJackpotOpponentSelect(btn);
          return;
        }

        if (customId.startsWith("gb_")) {
          await handleWoFButton(btn);
          return;
        }

        if (customId.startsWith("bj_")) {
          await handleBJButton(btn);
          return;
        }

        if (customId.startsWith("jp_")) {
          await handleJackpotButton(btn);
          return;
        }
      }

      if (interaction.isModalSubmit()) {
        const modal = interaction as ModalSubmitInteraction;
        if (customId.startsWith("gb_")) {
          await handleWoFModal(modal);
          return;
        }
        if (customId.startsWith("bj_")) {
          await handleBJModal(modal);
          return;
        }
        if (customId.startsWith("jp_")) {
          await handleJackpotModal(modal);
          return;
        }
      }

      if (interaction.isStringSelectMenu()) {
        const sel = interaction as StringSelectMenuInteraction;
        if (customId.startsWith("gb_")) {
          await handleWoFSelect(sel);
          return;
        }
        if (customId.startsWith("jp_")) {
          await handleJackpotSelect(sel);
          return;
        }
      }
    } catch (err) {
      logger.error({ err }, "Error handling gamble interaction");
    }
  });
}
