import {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  type GuildMember,
  TextChannel,
} from "discord.js";
import { logger } from "../lib/logger";

const WELCOME_CHANNEL_ID = "1507093021651370174";

export function createClient() {
  return new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });
}

export function registerWelcome(client: Client) {
  client.on("guildMemberAdd", async (member: GuildMember) => {
    try {
      let channel = member.guild.channels.cache.get(WELCOME_CHANNEL_ID);
      if (!channel) {
        channel = await member.guild.channels
          .fetch(WELCOME_CHANNEL_ID)
          .catch(() => undefined) ?? undefined;
      }

      if (!channel || !(channel instanceof TextChannel)) {
        logger.warn(
          { channelId: WELCOME_CHANNEL_ID },
          "Welcome channel not found or not a text channel",
        );
        return;
      }

      const joinedAt = member.joinedAt ?? new Date();
      const formattedDate = joinedAt.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });

      const avatarUrl = member.user.displayAvatarURL({
        size: 256,
        extension: "png",
      });

      const embed = new EmbedBuilder()
        .setTitle("Welcome to Do1T!")
        .setDescription(
          `Hey <@${member.id}>, welcome to **Do1T**! We're glad to have you here. 🎉`,
        )
        .setThumbnail(avatarUrl)
        .addFields(
          { name: "Username", value: member.user.username, inline: true },
          { name: "Joined", value: formattedDate, inline: true },
          {
            name: "Member #",
            value: `${member.guild.memberCount}`,
            inline: true,
          },
        )
        .setColor(0x5865f2)
        .setFooter({ text: "Do1T Discord" })
        .setTimestamp();

      await channel.send({
        content: `<@${member.id}>`,
        embeds: [embed],
      });

      logger.info({ userId: member.id }, "Sent welcome message");
    } catch (err) {
      logger.error({ err }, "Failed to send welcome message");
    }
  });
}
