import {
  type Client,
  EmbedBuilder,
  TextChannel,
  type Message,
} from "discord.js";
import { sql } from "drizzle-orm";
import { db, userLevelsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const LEVELUP_CHANNEL_ID = "1507488869380259960";

const LEVEL_THRESHOLDS: [number, number][] = [
  [10, 1],
  [25, 2],
  [50, 3],
  [100, 4],
  [150, 5],
  [250, 6],
  [500, 7],
  [750, 8],
  [900, 9],
  [1000, 10],
];

const LEVEL_ROLES: Record<number, string> = {
  1: "1507497223179468952",
  2: "1507497271137271878",
  3: "1507497304125345963",
  4: "1507497361004560426",
  5: "1507497407808540802",
  6: "1507497438460772352",
  7: "1507497515795222598",
  8: "1507497546107588750",
  9: "1507497577862398192",
  10: "1507497607432245298",
};

function getLevelForCount(count: number): number {
  let level = 0;
  for (const [threshold, lvl] of LEVEL_THRESHOLDS) {
    if (count >= threshold) level = lvl;
  }
  return level;
}

export function registerLevels(client: Client) {
  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot || !message.guild) return;

    const userId = message.author.id;
    const guildId = message.guild.id;

    try {
      const result = await db
        .insert(userLevelsTable)
        .values({ userId, guildId, messageCount: 1, currentLevel: 0 })
        .onConflictDoUpdate({
          target: [userLevelsTable.userId, userLevelsTable.guildId],
          set: {
            messageCount: sql`${userLevelsTable.messageCount} + 1`,
          },
        })
        .returning();

      const row = result[0];
      if (!row) return;

      const newCount = row.messageCount;
      const oldLevel = row.currentLevel;
      const newLevel = getLevelForCount(newCount);

      logger.info({ userId, newCount, oldLevel, newLevel }, "Message counted");

      if (newLevel > oldLevel) {
        await db
          .insert(userLevelsTable)
          .values({ userId, guildId, messageCount: newCount, currentLevel: newLevel })
          .onConflictDoUpdate({
            target: [userLevelsTable.userId, userLevelsTable.guildId],
            set: { currentLevel: newLevel },
          });

        const member = message.member ?? await message.guild.members.fetch(userId).catch(() => null);

        if (member) {
          if (oldLevel > 0) {
            const oldRoleId = LEVEL_ROLES[oldLevel];
            if (oldRoleId && member.roles.cache.has(oldRoleId)) {
              await member.roles.remove(oldRoleId).catch((err) => {
                logger.warn({ err, userId, oldLevel }, "Failed to remove old level role");
              });
            }
          }

          const newRoleId = LEVEL_ROLES[newLevel];
          if (newRoleId) {
            await member.roles.add(newRoleId).catch((err) => {
              logger.warn({ err, userId, newLevel }, "Failed to add new level role");
            });
          }
        }

        let channel = message.guild.channels.cache.get(LEVELUP_CHANNEL_ID);
        if (!channel) {
          channel =
            (await message.guild.channels
              .fetch(LEVELUP_CHANNEL_ID)
              .catch(() => null)) ?? undefined;
        }

        if (!channel || !(channel instanceof TextChannel)) {
          logger.warn(
            { channelId: LEVELUP_CHANNEL_ID },
            "Level-up channel not found or not a text channel",
          );
          return;
        }

        const avatarUrl = message.author.displayAvatarURL({
          size: 256,
          extension: "png",
        });

        const threshold = LEVEL_THRESHOLDS.find(([, lvl]) => lvl === newLevel)?.[0] ?? 0;
        const roleId = LEVEL_ROLES[newLevel];

        const embed = new EmbedBuilder()
          .setTitle(`🎉 Level ${newLevel} Unlocked!`)
          .setDescription(
            `Congrats <@${userId}>! You've reached **Level ${newLevel}** by sending ${threshold}+ messages. Keep grinding! 🔥\n${roleId ? `You've been given the <@&${roleId}> role!` : ""}`,
          )
          .setThumbnail(avatarUrl)
          .addFields(
            { name: "Username", value: message.author.username, inline: true },
            { name: "Level", value: `${newLevel}`, inline: true },
            { name: "Total Messages", value: `${newCount}`, inline: true },
          )
          .setColor(0xffd700)
          .setFooter({ text: "Do1T Discord" })
          .setTimestamp();

        await channel.send({
          content: `<@${userId}>`,
          embeds: [embed],
        });

        logger.info({ userId, newLevel, roleId }, "Sent level-up message and assigned role");
      }
    } catch (err) {
      logger.error({ err, userId }, "Error processing message for levels");
    }
  });
}
