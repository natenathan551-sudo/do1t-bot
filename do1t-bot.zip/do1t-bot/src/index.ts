import app from "./app";
import { logger } from "./lib/logger";
import { createClient, registerWelcome } from "./bot/welcome";
import { registerLevels } from "./bot/levels";
import { registerGamble } from "./bot/gamble";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

const token = process.env["DISCORD_BOT_TOKEN"];
if (!token) {
  logger.error("DISCORD_BOT_TOKEN is not set — bot will not start");
} else {
  const client = createClient();
  registerWelcome(client);
  registerLevels(client);
  registerGamble(client);

  client.once("ready", () => {
    logger.info({ tag: client.user?.tag }, "Discord bot is online");
  });

  client.login(token).catch((err) => {
    logger.error({ err }, "Discord bot login failed");
  });
}
